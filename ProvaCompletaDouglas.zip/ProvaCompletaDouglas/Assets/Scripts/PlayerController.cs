using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Player Animation")]
    public Animator animatorPlayer;
    private Vector2 movementInput;

    public float walkSpeed = 3.0f;
    private Rigidbody2D rb;
    private bool invertido= false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        // Combine both input methods (keyboard and your custom input)
        float movX = Input.GetAxis("Horizontal") + movementInput.x;
        float movY = Input.GetAxis("Vertical") + movementInput.y;
        
        // Clamp values between -1 and 1
        movX = Mathf.Clamp(movX, -1f, 1f);
        movY = Mathf.Clamp(movY, -1f, 1f);
        rb.linearVelocity = new Vector2(movX * walkSpeed, movY * walkSpeed);
        UpdateAnimation(movX, movY);
        if (invertido == true)
        {
           
        }
    }

    void UpdateAnimation(float movX, float movY)
    {
        // Reset all animation parameters firs
        animatorPlayer.SetBool("WalkRight", false);
        animatorPlayer.SetBool("WalkLeft", false);
        animatorPlayer.SetBool("WalkUp", false);
        animatorPlayer.SetBool("WalkDown", false);

        // Only set one direction at a time (prioritize horizontal over vertical)
        if (Mathf.Abs(movX) > Mathf.Abs(movY))
        {
            if (movX > 0) animatorPlayer.SetBool("WalkRight", true);
            else if (movX < 0) animatorPlayer.SetBool("WalkLeft", true);
        }
        else
        {
            if (movY > 0) animatorPlayer.SetBool("WalkUp", true);
            else if (movY < 0) animatorPlayer.SetBool("WalkDown", true);
        }
    }

    public void MoveUp(bool isPressed)
    {
        if (invertido == false) 
        { movementInput.y = isPressed ? 1f : (movementInput.y > 0f ? 0f : movementInput.y); }
        else { movementInput.y = isPressed ? -1f : (movementInput.y < 0f ? 0f : movementInput.y); }
    }

    public void MoveDown(bool isPressed)
    {
        if (invertido == false) { movementInput.y = isPressed ? -1f : (movementInput.y < 0f ? 0f : movementInput.y); }
        else { movementInput.y = isPressed ? 1f : (movementInput.y > 0f ? 0f : movementInput.y); }
    }

    public void MoveLeft(bool isPressed)
    {   if (invertido == false) {movementInput.x = isPressed ? -1f : (movementInput.x < 0f ? 0f : movementInput.x); }
        else { movementInput.x = isPressed ? 1f : (movementInput.x > 0f ? 0f : movementInput.x); }
    }

    public void MoveRight(bool isPressed)
    {   if (invertido == false) { movementInput.x = isPressed ? 1f : (movementInput.x > 0f ? 0f : movementInput.x); }
        else { movementInput.x = isPressed ? -1f : (movementInput.x < 0f ? 0f : movementInput.x); }
        
    }
    public void InvertController (bool isPressed)
    {
        invertido = true;
    }
}